
function computeAlignmentScore(candidateData, jobCriteria) {
    let alignment = 0;

    // Skill Check
    const alignedSkills = candidateData.skills.filter(skill => jobCriteria.mandatorySkills.includes(skill));
    alignment += (alignedSkills.length / jobCriteria.mandatorySkills.length) * 50;

    // Experience Check
    if (candidateData.yearsOfExperience >= jobCriteria.experienceThreshold) {
        alignment += 30; 
    }

    // Education Check
    if (jobCriteria.preferredEducation.includes(candidateData.education)) {
        alignment += 20;
    }

    return alignment;
}

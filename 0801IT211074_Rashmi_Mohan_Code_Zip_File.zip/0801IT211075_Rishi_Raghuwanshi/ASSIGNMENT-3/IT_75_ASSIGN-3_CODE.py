#!C:\Python311\python.exe
import cgi
import json

# Create instance of FieldStorage 
form = cgi.FieldStorage()

# Function to parse candidate resume form data
def parse_candidate_resume(form):
    # Retrieve resume file data
    resume_file = form['resume']
    if resume_file.filename:
        resume_data = resume_file.value
        # Process candidate resume data here
        # For simplicity, let's just print the resume data
        print ("Content-type:text/html\r\n\r\n")
        print ('<html>')
        print ('<head>')
        print ('<title>Resume Submission</title>')
        print ('</head>')
        print ('<body>')
        print ('<h2>Your Resume Submitted Successfully</h2>')
        print ('<h3>Thank You For Applying </h3>')
        print ('</body>')
        print ('</html>')
        
    else:
        print("Content-Type: text/plain")
        print()
        print("No resume file uploaded")

# Call function to parse candidate resume form
parse_candidate_resume(form)
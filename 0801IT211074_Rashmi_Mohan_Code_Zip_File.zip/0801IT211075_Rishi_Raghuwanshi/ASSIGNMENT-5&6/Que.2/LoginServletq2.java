package com.company.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get username and password from form
        String username = request.getParameter("username");
        String password = request.getParameter("pass");

        // Simulate authentication check (replace with your actual logic)
        if (username.equals("Ankush_Kurmi") && password.equals("1234")) {
            // Login successful - Create a session
            HttpSession session = request.getSession(); 
            session.setAttribute("username", username);

            // Redirect to welcome page
            response.sendRedirect("WelcomeServlet"); 
        } else {
            // Login failed - Display error on login page 
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<h1>Invalid username or password</h1>");
            out.println("<p>Please try again.</p>");
            request.getRequestDispatcher("index.html").include(request, response); 
        }
    }

}
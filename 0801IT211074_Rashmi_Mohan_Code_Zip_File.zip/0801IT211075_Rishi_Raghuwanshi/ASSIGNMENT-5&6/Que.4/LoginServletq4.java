package com.company.MVC;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.*;

import java.io.IOException;
import java.sql.*;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
//	 private static final String DB_URL = "jdbc:mysql://localhost:3306/it";
//	    private static final String DB_USER = "root";
//	    private static final String DB_PASSWORD = "12345lkjhg";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String userid = request.getParameter("userid");
        String password = request.getParameter("password");
        
        String DB_URL = "jdbc:mysql://localhost:3306/it";
	     String DB_USER = "root";
	  String DB_PASSWORD = "12345lkjhg";
	    
        if (userid != null && password != null) {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            	System.out.println("loginservlet ke andar");
                String sql = "SELECT * FROM users WHERE userid = ? AND password = ?"; // Replace 'users' with your table name
                try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                    stmt.setString(1, userid);
                    stmt.setString(2, password);

                    try (ResultSet rs = stmt.executeQuery()) {
                        if (rs.next()) {
                            // Successful login
                            String username = rs.getString("username"); // Assuming you have a 'username' column
                            HttpSession session = request.getSession(); 
                            session.setAttribute("userid", userid);
                            session.setAttribute("username", username);
                            response.sendRedirect("home.jsp"); 
                        } else {
                            // Invalid credentials
                            response.sendRedirect("login.jsp?error=true"); 
                        }
                    }
                }
            } catch (SQLException e) {
                // Handle database errors
                request.setAttribute("error", "Database Error. Please contact administrator.");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } else {
           // Missing parameters - This should ideally never happen if you have client-side validation
           request.setAttribute("error", "Please enter User ID and password.");
           request.getRequestDispatcher("login.jsp").forward(request, response);
        }
	}

}

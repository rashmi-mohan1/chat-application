package com.company.MVC;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	
//
//	 public static final String DB_URL = "jdbc:mysql://localhost:3306/it";
//	    public static final String DB_USER = "root";
//	    public static final String DB_PASSWORD = "12345lkjhg";
	 	
   
    public UserServlet() {
        super();
       
    }

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		  if (req.getParameter("logout") != null) {
	            req.getSession().invalidate();
	            resp.sendRedirect("login.jsp");
	        } else if (req.getParameter("edit") != null) {
	            handleEditProfile(req, resp);
	        } else {
	           //  ... other possible doGet actions ...
	        }
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 // Determine action (Login, Registration, etc.)
        if (request.getParameter("userid") != null) { 
            // Handle login (You already have the LoginServlet for this)
        } else if (request.getParameter("registrationData") != null) {
        	System.out.println("andar aa gya");
            handleRegistration(request, response);
        } else {
            // Unknown action 
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid Request");
        }
	}

	   private void handleRegistration(HttpServletRequest request, HttpServletResponse response) 
	            throws ServletException, IOException {

			String url="jdbc:mysql://localhost:3306/ankush";
	       	String username="root";
	       	String password="12345lkjhg";
			     try {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	        // 1. Get all registration form data from the request
		   String firstName = request.getParameter("firstName");
		    String middleName = request.getParameter("middleName");
		    String lastName = request.getParameter("lastName");
		    String department = request.getParameter("department");
		    String rollGroup = request.getParameter("rollGroup");
		    String rollSeries = request.getParameter("rollSeries");
		    String rollNumber = request.getParameter("rollNumber");
		   // String[] activities = request.getParameterValues("activities");
	        // 2. Validate input (omitted for brevity, but important!)
		    
		    System.out.println(rollNumber);

	        // 3. Database Interaction:
	        try (Connection conn=DriverManager.getConnection(url, username, password);) {
	            System.out.println("connection estd");
	            String sql = "INSERT INTO users (firstName, middleName, lastName, department, rollGroup, rollSeries, rollNumber) VALUES (?, ?, ?, ?, ?, ?, ?)"; // Replace with the correct table and column names 
	            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
	            	 stmt.setString(1, firstName);
	                 stmt.setString(2, middleName);
	                 stmt.setString(3, lastName);
	                 stmt.setString(4, department);
	                 stmt.setString(5, rollGroup);
	                 stmt.setString(6, rollSeries);
	                 stmt.setString(7, rollNumber);

	                 stmt.executeUpdate();

	                 // Success! 
	                 System.out.println("inser to ho gya");
	                 response.sendRedirect("login.jsp");
	            }
	        } catch (SQLException e) {
	        	if (e.getErrorCode() == 1062) { // Assuming 1062 is the error code for a unique key violation
	                request.setAttribute("error", "Roll number already exists");
	           } else {
	               request.setAttribute("error", "Database Error. Please contact administrator.");
	           }
	           request.getRequestDispatcher("registration.jsp").forward(request, response); 
	        } 
	    }

	    private void handleEditProfile(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {
	        // 1. Check if user is logged in (session)

	        // 2. Retrieve existing data from database (based on userid from session)
	        //     and pass this data to registration.jsp to populate the form

	        // 3. When the form with updates is submitted, write an UPDATE SQL query, similar to the registration logic
	    }
}

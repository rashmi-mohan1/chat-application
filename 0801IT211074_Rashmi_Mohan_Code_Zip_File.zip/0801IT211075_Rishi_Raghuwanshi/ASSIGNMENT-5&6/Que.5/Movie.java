package com.company.movie;

public class Movie {
    private String title;
    private String releaseDate;
    private String director;
    private String[] actors;
    private String category;
    private String summary;

    // Constructor
    public Movie(String title, String releaseDate, String director, String[] actors, String category, String summary) {
        this.title = title;
        this.releaseDate = releaseDate;
        this.director = director;
        this.actors = actors;
        this.category = category;
        this.summary = summary;
    }

    // Getters
    public String getTitle() {
        return title;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public String getDirector() {
        return director;
    }

    public String[] getActors() {
        return actors;
    }

    public String getCategory() {
        return category;
    }

    public String getSummary() {
        return summary;
    }

    // Setters
    public void setTitle(String title) {
        this.title = title;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public void setActors(String[] actors) {
        this.actors = actors;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }
}


package com.company.movie;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

/**
 * Servlet implementation class MovieServlet
 */
public class MovieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	private HashMap<String, Movie> movies = new HashMap<>();

    @Override
    public void init() throws ServletException {
        // Add sample movies 
        movies.put("The Shawshank Redemption", new Movie("The Shawshank Redemption", "1994", "Frank Darabont", new String[]{"Tim Robbins", "Morgan Freeman"}, "Drama", "Two imprisoned men ..."));
        movies.put("The Godfather", new Movie("The Godfather", "1972", "Francis Ford Coppola", new String[]{"Marlon Brando", "Al Pacino"}, "Crime", "The aging patriarch of an organized crime dynasty..."));
        movies.put("The Dark Knight", new Movie("The Dark Knight", "2008", "Christopher Nolan", new String[]{"Christian Bale", "Heath Ledger"}, "Action", "Batman faces a reign of chaos..."));
        movies.put("Pulp Fiction", new Movie("Pulp Fiction", "1994", "Quentin Tarantino", new String[]{"John Travolta", "Samuel L. Jackson"}, "Crime", "The lives of two mob hitmen..."));
        movies.put("Forrest Gump", new Movie("Forrest Gump", "1994", "Robert Zemeckis", new String[]{"Tom Hanks", "Robin Wright"}, "Drama", "Forrest Gump, a man with a low IQ..."));
        movies.put("Inception", new Movie("Inception", "2010", "Christopher Nolan", new String[]{"Leonardo DiCaprio", "Joseph Gordon-Levitt"}, "Sci-Fi", "A thief who steals corporate secrets..."));
        movies.put("The Matrix", new Movie("The Matrix", "1999", "Lana Wachowski, Lilly Wachowski", new String[]{"Keanu Reeves", "Laurence Fishburne"}, "Sci-Fi", "A computer hacker learns from mysterious rebels..."));
        movies.put("Back to the Future", new Movie("Back to the Future", "1985", "Robert Zemeckis", new String[]{"Michael J. Fox", "Christopher Lloyd"}, "Sci-Fi", "Marty McFly, a 17-year-old high school student..."));
        movies.put("The Lord of the Rings: The Return of the King", new Movie("The Lord of the Rings: The Return of the King", "2003", "Peter Jackson", new String[]{"Elijah Wood", "Viggo Mortensen"}, "Fantasy", "Gandalf and Aragorn lead the World of Men against Sauron's army..."));
        movies.put("Spirited Away", new Movie("Spirited Away", "2001", "Hayao Miyazaki", new String[]{"Daveigh Chase", "Suzanne Pleshette"}, "Animation", "During her family's move to the suburbs..."));
    }
	 
	 
	 
    public MovieServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        if (request.getParameter("title") != null) {
            // Display Movie Details
            displayMovieDetails(request, response, out);
        } else {
            // Display Movie List (Default)
            displayMovieList(out);
        }
	}

	
	  private void displayMovieList(PrintWriter out) {
	        out.println("<h1>Movie List</h1>");
	        out.println("<ul>");
	        for (String movieTitle : movies.keySet()) {
	            out.println("<li><a href='?title=" + movieTitle + "'>" + movieTitle + "</a></li>");
	        }
	        out.println("</ul>");
	    }
	    private void displayMovieDetails(HttpServletRequest request, HttpServletResponse response, PrintWriter out) {
	        String title = request.getParameter("title");
	        Movie movie = movies.get(title);

	        if (movie != null) {
	            out.println("<h1>" + movie.getTitle() + "</h1>");
	            out.println("<p>Release Date: " + movie.getReleaseDate() + "</p>");
	            out.println("<p>Director: " + movie.getDirector() + "</p>");
	            out.println("<p>Category: " + movie.getCategory() + "</p>");
	            out.println("<p>Summary: " + movie.getSummary() + "</p>");

	            // Display Actors 
	            out.println("<p>Actors: </p><ul>");
	            for (String actor : movie.getActors()) { 
	                out.println("<li>" + actor + "</li>");
	            } 
	            out.println("</ul>"); 

	        } else {
	            out.println("Movie not found!"); 
	        }
	    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
